FlashPy
=======

This is a module designed to work with hdf5 output files from `FLASH <http://flash.uchicago.edu/site/>`__ simulations. 
It provides basic analysis tools, and methods for the importation and visualisation of the files. 


