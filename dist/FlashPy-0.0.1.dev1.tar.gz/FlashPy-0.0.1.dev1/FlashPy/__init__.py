
import logging

def main():

    logging.info("I'm alive!")

